

function SideBar() {

    return (
        <>
            <h1>Menu</h1>
            <ul className="list-group">
                <li className="list-group-item"><a href="/">Item 1</a></li>
                <li className="list-group-item"><a href="/">Item 2</a></li>
                <li className="list-group-item"><a href="/">Item 3</a></li>
                <li className="list-group-item"><a href="/">Item 4</a></li>
                <li className="list-group-item"><a href="/">Item 5</a></li>
                <li className="list-group-item"><a href="/">Item 6</a></li>
                <li className="list-group-item"><a href="/">Item 7</a></li>
                <li className="list-group-item"><a href="/">Item 8</a></li>
                <li className="list-group-item"><a href="/">Item 9</a></li>
                <li className="list-group-item"><a href="/">Item 10</a></li>
            </ul>
        </>
    )
}

export default SideBar