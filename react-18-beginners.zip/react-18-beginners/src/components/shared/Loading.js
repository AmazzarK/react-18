
function Loading({children}) {
  return (
    <p className='text-center my-5'>{children}</p>
  )
}

export default Loading