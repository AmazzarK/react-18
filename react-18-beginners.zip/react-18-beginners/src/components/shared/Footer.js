

function Footer() {

    return (
        <>
            <div className="text-center my-4 py-3">Copyright &copy; 2023 - Coding Tech</div>
        </>
    )
}

export default Footer