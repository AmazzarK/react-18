import Users from './components/users/Users';
import './App.css';


function App() {
  return (
    <div className="container">
      <Users></Users>
    </div>
  );
}

export default App;
