
function Paragraph() {

    return (
        <>
            <h1>Welcome to Coding Tech</h1>
            <button className="btn btn-primary">Salam</button>
        </>
    )

}

export default Paragraph